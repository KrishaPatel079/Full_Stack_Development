// src/api/omdb.js
import axios from "axios";

const API_KEY = import.meta.env.VITE_OMDB_API_KEY;
const BASE = "https://www.omdbapi.com/";

const omdb = axios.create({
  baseURL: BASE,
  params: { apikey: API_KEY },
});

// Search movies by keyword (returns array of results or empty array)
export async function searchMovies(query, page = 1, type = "movie") {
  if (!query) return [];
  const res = await omdb.get("/", { params: { s: query, page, type, r: "json" } });
  if (res.data?.Response === "False") return [];
  return res.data?.Search || [];
}

// Get detailed info by imdbID
export async function getMovieDetails(imdbID) {
  if (!imdbID) return null;
  const res = await omdb.get("/", { params: { i: imdbID, plot: "full", r: "json" } });
  if (res.data?.Response === "False") return null;
  return res.data;
}

// Example "trending" fallback (OMDb has no trending endpoint; we use a popular keyword set)
export async function fetchTrending() {
  // You can customize these keywords to change what shows on the "Trending" row
  const keyword = "Avengers"; // simple fallback
  return await searchMovies(keyword, 1, "movie");
}

export default omdb;
