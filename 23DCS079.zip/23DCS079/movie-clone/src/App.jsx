import React, { useState } from "react";
import Navbar from "./components/Navbar";
import Banner from "./components/Banner";
import Row from "./components/Row";
import TrailerModal from "./components/TrailerModal";

export default function App() {
  const [selected, setSelected] = useState(null); // movie object

  return (
    <div className="app">
      <Navbar />
      <Banner />
      <main>
        <Row title="Trending" query="Avengers" onCardClick={(m) => setSelected(m)} isLargeRow />
        <Row title="Marvel" query="Marvel" onCardClick={(m) => setSelected(m)} />
        <Row title="Batman" query="Batman" onCardClick={(m) => setSelected(m)} />
        <Row title="Comedy" query="Comedy" onCardClick={(m) => setSelected(m)} />
      </main>

      {selected && (
        <TrailerModal
          title={selected.Title}
          onClose={() => setSelected(null)}
        />
      )}
    </div>
  );
}
