import React, { useEffect, useState } from "react";
import YouTube from "react-youtube";

/*
  Behavior:
  - If VITE_YOUTUBE_API_KEY is set, the modal will call YouTube Data API
    to find the first "title trailer" video and embed it.
  - If no key is provided, the modal shows a link button to open a YouTube search
    (simple fallback; embedding requires an API key or a saved video id).
*/

export default function TrailerModal({ title, onClose }) {
  const YT_KEY = import.meta.env.VITE_YOUTUBE_API_KEY;
  const [videoId, setVideoId] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let mounted = true;
    if (!title) return;
    if (!YT_KEY) return; // no key -> fallback (user will click open)
    setLoading(true);
    (async () => {
      try {
        const q = encodeURIComponent(`${title} trailer`);
        const url = `https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=1&q=${q}&type=video&key=${YT_KEY}`;
        const resp = await fetch(url);
        const json = await resp.json();
        const id = json?.items?.[0]?.id?.videoId;
        if (mounted && id) setVideoId(id);
      } catch (e) {
        console.error("YouTube fetch error", e);
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => (mounted = false);
  }, [title, YT_KEY]);

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-inner" onClick={(e) => e.stopPropagation()}>
        <button className="modal-close" onClick={onClose}>✕</button>

        {YT_KEY ? (
          loading ? (
            <div style={{ padding: 40 }}>Searching trailer...</div>
          ) : videoId ? (
            <YouTube videoId={videoId} opts={{ width: "100%", playerVars: { autoplay: 1 } }} />
          ) : (
            <div style={{ padding: 20 }}>
              Trailer not found. <br/>
              <a target="_blank" rel="noreferrer" href={`https://www.youtube.com/results?search_query=${encodeURIComponent(title + " trailer")}`}>
                Open YouTube search
              </a>
            </div>
          )
        ) : (
          <div style={{ padding: 20 }}>
            <p>No YouTube API key configured.</p>
            <a target="_blank" rel="noreferrer" href={`https://www.youtube.com/results?search_query=${encodeURIComponent(title + " trailer")}`}>
              Open YouTube search for "{title} trailer"
            </a>
          </div>
        )}
      </div>
    </div>
  );
}
