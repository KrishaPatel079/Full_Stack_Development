import React from "react";

const FALLBACK = "/placeholder-poster.png";

export default function MovieCard({ movie, isLargeRow, onClick }) {
  const poster = movie?.Poster && movie.Poster !== "N/A" ? movie.Poster : FALLBACK;
  return (
    <div className={`movie-card ${isLargeRow ? "large" : ""}`} onClick={onClick}>
      <img src={poster} alt={movie.Title} loading="lazy" />
      <div className="card-info">
        <div className="card-title">{movie.Title}</div>
        <div className="card-year">{movie.Year}</div>
      </div>
    </div>
  );
}
