import React from "react";

export default function Navbar() {
  return (
    <nav className="nav">
      <img
        className="nav-logo"
        src="https://upload.wikimedia.org/wikipedia/commons/7/7a/Logonetflix.png"
        alt="Logo"
      />
      <div className="nav-right">
        <input className="nav-search" placeholder="Search movies..." />
        <img
          className="nav-avatar"
          src="https://upload.wikimedia.org/wikipedia/commons/0/0b/Netflix-avatar.png"
          alt="avatar"
        />
      </div>
    </nav>
  );
}
