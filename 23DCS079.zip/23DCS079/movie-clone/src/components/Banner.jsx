import React, { useEffect, useState } from "react";
import { searchMovies, getMovieDetails } from "../api/omdb";
import TrailerModal from "./TrailerModal";

export default function Banner() {
  const [movie, setMovie] = useState(null);
  const [trailerTitle, setTrailerTitle] = useState("");

  useEffect(() => {
    let mounted = true;
    (async () => {
      const list = await searchMovies("Avengers");
      if (mounted && list.length) {
        const pick = list[Math.floor(Math.random() * list.length)];
        const details = await getMovieDetails(pick.imdbID);
        if (mounted) setMovie(details);
      }
    })();
    return () => (mounted = false);
  }, []);

  if (!movie) return <div style={{ height: 320 }} />; // space while loading

  const poster =
    movie.Poster && movie.Poster !== "N/A" ? movie.Poster : "/placeholder-poster.png";

  return (
    <header
      className="banner"
      style={{
        backgroundImage: `linear-gradient(to top, rgba(0,0,0,0.7) 10%, rgba(0,0,0,0.1)), url("${poster}")`
      }}
    >
      <div className="banner-contents">
        <h1 className="banner-title">{movie.Title}</h1>
        <p className="banner-description">{movie.Plot}</p>
        <div className="banner-buttons">
          <button onClick={() => setTrailerTitle(movie.Title)}>Play Trailer</button>
          <button>My List</button>
        </div>
      </div>

      {trailerTitle && (
        <TrailerModal title={trailerTitle} onClose={() => setTrailerTitle("")} />
      )}
    </header>
  );
}
