import React, { useEffect, useRef, useState } from "react";
import { searchMovies } from "../api/omdb";
import MovieCard from "./MovieCard";

export default function Row({ title, query, isLargeRow = false, onCardClick }) {
  const [movies, setMovies] = useState([]);
  const containerRef = useRef();

  useEffect(() => {
    let mounted = true;
    (async () => {
      const list = await searchMovies(query || title, 1, "movie");
      if (mounted) setMovies(list);
    })();
    return () => (mounted = false);
  }, [query, title]);

  const scroll = (dir = 1) => {
    const el = containerRef.current;
    if (!el) return;
    el.scrollBy({ left: dir * 600, behavior: "smooth" });
  };

  return (
    <section className="row">
      <h2>{title}</h2>
      <div className="row-controls">
        <button onClick={() => scroll(-1)}>‹</button>
        <div className="row-posters" ref={containerRef}>
          {movies.map((m) => (
            <MovieCard key={m.imdbID} movie={m} isLargeRow={isLargeRow} onClick={() => onCardClick?.(m)} />
          ))}
        </div>
        <button onClick={() => scroll(1)}>›</button>
      </div>
    </section>
  );
}
